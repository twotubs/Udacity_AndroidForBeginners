package com.example.android.quiz_app_phish;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    double answerOne = 0.0;
    double answerTwo = 0.0;
    double answerThree = 0.0;
    double answerFour = 0.0;
    double shownights = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    /*
    This method increments the number of shows.
    2. NEED TO ADD A TOAST INTO THIS PART TO SAY THAT IF YOU ARE HIGHER THAN 20 YOU ARE TOO MUCH
     */
    public void increment(View view) {
        shownights = shownights + 1;
        displayShownights(shownights);
    }

    /*
    This method reduces the number of shows.
    2. NEED TO ADD A TOAST INTO THIS PART TO SAY THAT IF YOU ARE LOWER THAN 1 YOU ARE TOO LITTLE
     */

    public void decrement(View view) {
        shownights = shownights - 1;
        displayShownights(shownights);
    }

    public void submitAnswers(View view) {
        //Get the user's name
        EditText nameEntered = (EditText) findViewById(R.id.enter_name_field);
        Editable nameEditable = nameEntered.getText();
        String nameOfUser = nameEditable.toString();

//QUESTION ONE
        //calculate scoreone by passing shownights to the calculateQuestionOne method
        double scoreOne = calculateQuestionOne(shownights);


//QUESTION TWO
        // Figure out if the user clicked on Trey
        CheckBox questionTwoCheckboxOne = (CheckBox) findViewById(R.id.trey_checkbox);
        boolean checkbox1 = questionTwoCheckboxOne.isChecked();

        // Figure out if the user clicked on Mike
        CheckBox questionTwoCheckboxTwo = (CheckBox) findViewById(R.id.mike_checkbox);
        boolean checkbox2 = questionTwoCheckboxTwo.isChecked();

        // Figure out if the user clicked on Page
        CheckBox questionTwoCheckboxThree = (CheckBox) findViewById(R.id.page_checkbox);
        boolean checkbox3 = questionTwoCheckboxThree.isChecked();

        // Figure out if the user clicked on Fish
        CheckBox questionTwoCheckboxFour = (CheckBox) findViewById(R.id.fish_checkbox);
        boolean checkbox4 = questionTwoCheckboxFour.isChecked();

        // Figure out if the user clicked on Randy
        CheckBox questionTwoCheckboxFive = (CheckBox) findViewById(R.id.randy_checkbox);
        boolean checkbox5 = questionTwoCheckboxFive.isChecked();

        //calculate scoreTwo by passing checkboxes to the calculateQuestionTwo method
        double scoreTwo = calculateQuestionTwo(checkbox1, checkbox2, checkbox3, checkbox4, checkbox5);

//QUESTION THREE
        EditText cityEntered = (EditText) findViewById(R.id.city_name);
        Editable cityEditable = cityEntered.getText();
        String nameOfCity = cityEditable.toString();

        //calculate questionThree by grabbing text and checking it in calculatequestionThree method
        double scoreThree = calculateQuestionThree(nameOfCity);

        // QUESTION FOUR
        //INPUTS FOR QUESTION Four
        RadioButton questionFourRadioOne = (RadioButton) findViewById(R.id.radio_gordon);
        boolean radioButtonOne = questionFourRadioOne.isChecked();

        RadioButton questionFourRadioTwo = (RadioButton) findViewById(R.id.radio_mike);
        boolean radioButtonTwo = questionFourRadioTwo.isChecked();

        double scoreFour = calculateQuestionFour(radioButtonOne, radioButtonTwo);

        //show answers on screen when button pressed
        TextView showAnswerSummary = (TextView) findViewById(R.id.answer_summary_field);
        showAnswerSummary.setText(
                "Hello " + nameOfUser +
                        "\n You got " + scoreOne + " points for question one." +
                        "\n You got " + scoreTwo + " points for question two." +
                        "\n You got " + scoreThree + " points for question three."+
                        "\n You got " + scoreFour + " point for question four"
        );

        double totalScore = scoreOne + scoreTwo + scoreThree + scoreFour;

        //This is the toast that pops up and tells the user their score out of 5
        Context context = getApplicationContext();
        CharSequence text = "Your score is "+ totalScore + " out of 4";
        int duration = Toast.LENGTH_SHORT;

        Toast toast = Toast.makeText(context, text, duration);
        toast.show();

    }

    //give one point for the right number of nights (13)
    private double calculateQuestionOne(double shownights) {
        if (shownights == 13) {
            answerOne = answerOne +1.0;
        } else {
            answerOne = answerOne + 0.0;
        }
        return answerOne;
    }

    //give 0.25 points for each correct guess of the band members (trey, mike, page, fish)
    private double calculateQuestionTwo(boolean checkbox1, boolean checkbox2, boolean checkbox3, boolean checkbox4, boolean checkbox5) {
        //first start with the score at 0.  User get's 0.25 points for each write guess, and 0.25 points for the wrong guess

        //if user selected Trey give them 0.25 points
        if(checkbox1) {
            answerTwo = answerTwo + 0.25;
        }
        //if user selected Mike give them 0.25 points
        if(checkbox2) {
            answerTwo = answerTwo + 0.25;
        }
        //if user selected Page give them 0.25 points
        if(checkbox3) {
            answerTwo= answerTwo + 0.25;
        }
        //if user selected Page give them 0.25 points
        if(checkbox4) {
            answerTwo = answerTwo + 0.25;
        }
        //if user selected Randy TAKEAWAY 0.25 points
        if(checkbox5){
            answerTwo = answerTwo - 0.25;
        }

        return answerTwo;
    }

    private double calculateQuestionThree(String nameOfCity) {
        if (nameOfCity.equals("New York")) {
            answerThree = answerThree + 1.0;
        }
        if (nameOfCity.equals("NYC")) {
            answerThree = answerThree + 1.0;
        }
        if (nameOfCity.equals("The Big Apple")) {
            answerThree = answerThree + 1.0;
        } else {
            answerThree = answerThree + 0.0;
        }
        return answerThree;
    }

    private double calculateQuestionFour(boolean radioButtonOne, boolean radioButtonTwo){
        if(radioButtonOne){
            answerFour+=0;
        } if (radioButtonTwo){
            answerFour+=0;
        } else {
            answerFour+=1;
        }
        return answerFour;
    }

    //takes the parameter shownights and displays it on the screen
    public void displayShownights(double numberOfShownights) {
        TextView shownightTextView = (TextView) findViewById(R.id.number_of_nights);
        shownightTextView.setText("" + numberOfShownights);
    }

}
